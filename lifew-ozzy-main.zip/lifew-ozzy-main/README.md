<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>EARLY BIRD BEVERAGE/</title>
</head>
<style>
</style>
<body>
  <main>
<h1>EARLY BIRD BEVERAGE</h1>
  <ul>
  <li>Coffee</li>
  <img src="images/Almond-Milk-Coffee-001.webp">
  <li>Tea</li>
  <img src="images/pexels-photo-2659387.jpeg">
  <dl>
  <dd>Black Tea</dd>  
  <img src="images/istockphoto-478987868-612x612.jpg">
  <dd>Green Tea</dd>
  <img src="images/cups-green-tea-table-wooden-background-61901598.jpg">
  </dl>
  <ul>

  <ul>
<li>Milk</li>
<img src="images/200377-050-4326767F.webp">
<ul>

  <main>
  </body>
  </html>
